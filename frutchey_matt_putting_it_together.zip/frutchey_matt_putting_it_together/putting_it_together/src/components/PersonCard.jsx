import { useState } from "react";
/* eslint-disable react/prop-types */
const PersonCard = (props) => {
    const { firstName, lastName, age, hairColor } = props;
    const [ increaseAge, setIncreaseAge ] = useState(age); 
    return (
        <div>
            <h2>{ firstName } { lastName }</h2>
            <p>Age: { increaseAge }</p>
            <p>Hair Color: { hairColor }</p>
            <button onClick = { () => setIncreaseAge(increaseAge + 1)}>Birthday Button for { firstName } { lastName }</button>
        </div>
    );
}
export default PersonCard;