/* eslint-disable react/prop-types */
import PersonCard from './components/PersonCard';
import './App.css'

function App() {
  return (
    <div>
      <PersonCard
        firstName = {" Ron "}
        lastName = { " Burgundy " }
        age = { 37 }
        hairColor = { "Brown" }
      />
      <hr />
      <PersonCard 
        firstName = {" Veronica "} 
        lastName = { " Corningstone " }
        age = { 35 }
        hairColor = { "Blonde" }
        />
        <hr />
      <PersonCard
        firstName = {" Brick "}
        lastName = {" Tamland "}
        age = { 48 }
        hairColor = {" Dark Brown "}
        />
        <hr />
      <PersonCard
        firstName = { " Brian " }
        lastName = { " Fantana " }
        age = { 32 }
        hairColor = { "Black" }
        />
    </div>
  )
}

export default App
